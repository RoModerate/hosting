console.log("bot started"); setInterval(()=>{},1000)
