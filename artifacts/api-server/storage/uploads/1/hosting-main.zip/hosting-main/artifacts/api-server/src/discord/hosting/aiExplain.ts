import { logger } from "../../lib/logger";

const OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions";
const MODEL = process.env["OPENROUTER_MODEL"] || "openai/gpt-4o-mini";

/**
 * Ask an LLM (via OpenRouter, using the operator's own account) to translate a
 * raw hosting failure/error log into a short, plain-language explanation for
 * the customer. Returns null (never throws) if the key is missing or the
 * request fails, so hosting flows never block on this.
 */
export async function explainHostingFailure(params: {
  message: string;
  detail?: string;
  fileName: string;
}): Promise<string | null> {
  const apiKey = process.env["OPENROUTER_API_KEY"];
  if (!apiKey) {
    logger.warn(
      "OPENROUTER_API_KEY not set; skipping AI failure explanation",
    );
    return null;
  }

  const { message, detail, fileName } = params;
  const prompt = [
    `A customer's uploaded Discord bot ("${fileName}") failed to host. Outcome: ${message}`,
    detail
      ? `Captured install/startup output (may include the root cause):\n${detail.slice(0, 4000)}`
      : "",
    "",
    "Explain to the customer, in plain, professional, non-technical language, what most likely went wrong and what they should check or fix in their code or configuration. If the log clearly points to a specific cause (missing dependency, missing token/env var, syntax error, wrong entry file, port conflict, etc.), name it directly. Keep the explanation to 3-6 sentences. Do not use emojis or markdown headings.",
  ]
    .filter(Boolean)
    .join("\n\n");

  try {
    const response = await fetch(OPENROUTER_URL, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: MODEL,
        messages: [{ role: "user", content: prompt }],
        temperature: 0.3,
      }),
    });

    if (!response.ok) {
      const text = await response.text().catch(() => "");
      logger.error(
        { status: response.status, text },
        "OpenRouter request failed",
      );
      return null;
    }

    const data = (await response.json()) as {
      choices?: Array<{ message?: { content?: string } }>;
    };
    const content = data.choices?.[0]?.message?.content?.trim();
    return content || null;
  } catch (err) {
    logger.error({ err }, "Failed to call OpenRouter for failure explanation");
    return null;
  }
}
